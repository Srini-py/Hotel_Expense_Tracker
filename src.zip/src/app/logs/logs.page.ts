import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertController, IonItemSliding, ModalController } from '@ionic/angular';
import { AddLogComponent } from './add-log/add-log.component';
import { Log } from './log.model';
import { LogsService } from './logs.service';

@Component({
  selector: 'app-logs',
  templateUrl: './logs.page.html',
  styleUrls: ['./logs.page.scss'],
})
export class LogsPage implements OnInit {
  recordList: Log[];
  recordList1: Log[];
  recordList2: Log[];
  allRecordList: Log[];
  record: Log;
  segmentValue: string;
  order: string = "all"
  orderType: string = "created"

  constructor(
    private ls: LogsService,
    private router: Router,
    private modalCtrl: ModalController,
    private alertCtrl: AlertController,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.ls.logs.subscribe(logs => {
      this.allRecordList = logs;
      this.recordList = [...this.allRecordList];
      this.recordList1 = [...this.allRecordList];
      this.recordList2 = [...this.recordList1];
    });
  }

  ionViewWillEnter() {
    this.ls.fetchLogs().subscribe();
  }

  onFilterUpdate(event) {
    this.orderType = 'created'
    this.onFilterUpdate2(event.detail.value);
  }

  onFilterUpdate2(value) {
    this.recordList1 = [...this.allRecordList];
    if(value === 'all') {
      this.recordList1 = [...this.allRecordList];
    }
    else if(value === 'expenses') {
      this.recordList1 = this.allRecordList.filter(record => record.logType === 'Expense' );
    }
    else if(value === 'incomes') {
      this.recordList1 = this.allRecordList.filter(record => record.logType === 'Income' );
    }
    this.recordList = [...this.recordList1];
    this.order = value
  }

  onOrderUpdate(event) {
    this.onOrderUpdate2(event.detail.value);
  }

  onOrderUpdate2(value) {
    this.recordList2 = [...this.recordList1];
    if(value === 'created') {
      this.recordList2 = [...this.recordList1];
    }
    else if(value === 'oldest') {
      this.recordList2.sort((obj1, obj2) => {
        var c = new Date(obj1.date)
        var d = new Date(obj2.date)
        return (c > d)? 1: -1;
      })
    }
    else if(value === 'newest') {
      this.recordList2.sort((obj1, obj2) => {
        var c = new Date(obj1.date)
        var d = new Date(obj2.date)
        return (c > d)? 1: -1;
      })
      this.recordList2.reverse();
    }
    else if(value === 'alphabetic') {
      this.recordList2.sort((obj1, obj2) => (obj1.entry > obj2.entry)? 1: -1);
    }
    else if(value === 'dept') {
      this.recordList2.sort((obj1, obj2) => (obj1.department > obj2.department)? 1: -1);
    }
    else if(value === 'amount') {
      this.recordList2.sort((obj1, obj2) => (obj1.value > obj2.value)? 1: -1);
    }
    this.recordList = [...this.recordList2];
    this.orderType = value
  }

  onCreateLog() {
    this.openLogModal();
  }

  openLogModal() {
    this.modalCtrl
      .create({
        component: AddLogComponent,
        componentProps: { listLength: this.allRecordList.length },
      })
      .then((modalEl) => {
        modalEl.present();
        return modalEl.onDidDismiss();
      })
      .then((res) => {
        if (res.role == 'confirm') {
          this.ls.addNewLog(
            res.data.logData.department,
            res.data.logData.logType,
            res.data.logData.entry,
            res.data.logData.value,
            res.data.logData.date
          ).subscribe();
          this.ls.logs.subscribe(logs => {
            this.allRecordList = logs;
            this.recordList = [...this.allRecordList];
            this.recordList1 = [...this.allRecordList];
            this.recordList2 = [...this.recordList1];
            this.onFilterUpdate2(this.order);
            this.onOrderUpdate2(this.orderType);
          });
          // this.recordList.push(
          //   new Log(
          //     res.data.logData.id,
          //     res.data.logData.department,
          //     res.data.logData.logType,
          //     res.data.logData.entry,
          //     res.data.logData.value,
          //     res.data.logData.date,
          //   )
          // )
        }
      });
  }

  onEdit(logId: string, slidingEl: IonItemSliding) {
    slidingEl.close();
    this.router.navigate(['/', 'logs', 'edit-log', logId]);
  }

  onDelete(logId: string, slidingEl: IonItemSliding) {
    slidingEl.close();
    this.alertCtrl
      .create({
        header: 'Confirm Delete',
        message: 'Do you want to confirm delete?',
        buttons: [
          {
            text: 'Ok',
            handler: () => {
              this.ls.deleteLog(logId).subscribe();
              this.ls.logs.subscribe(logs => {
                this.allRecordList = logs;
                this.recordList = [...this.allRecordList];
                this.recordList1 = [...this.allRecordList];
                this.recordList2 = [...this.recordList1];
                this.onFilterUpdate2(this.order);
                this.onOrderUpdate2(this.orderType);
              });
            },
          },
          {
            text: 'Cancel',
            role: 'cancel'
          }
        ],
      })
      .then((alertEl) => {
        alertEl.present();
      });
  }
}

// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { IonItemSliding, ModalController } from '@ionic/angular';
// import { Subscription } from 'rxjs';
// import { AddLogComponent } from './add-log/add-log.component';
// import { Log } from './log.model';
// import { LogsService } from './logs.service';

// @Component({
//   selector: 'app-logs',
//   templateUrl: './logs.page.html',
//   styleUrls: ['./logs.page.scss'],
// })
// export class LogsPage implements OnInit, OnDestroy {
//   recordList: Log[];
//   record: Log;
//   logsSub: Subscription;

//   constructor(
//     private ls: LogsService,
//     private modctrl: ModalController,
//     private router: Router
//   ) {}

//   ngOnInit() {
//     console.log("Logs Page Init before subscription");
//     this.logsSub = this.ls.logs.subscribe((logs) => {
//       this.recordList = logs;
//       console.log("Logs Page Init after subscription");
//     });
//   }

//   ngOnDestroy() {
//     if (this.logsSub) this.logsSub.unsubscribe();
//   }

//   ionViewWillEnter() {
//     console.log("Logs Page Ionview before subscription");
//     this.ls.fetchLogs().subscribe();
//     console.log("Logs Page Ionview after subscription");
//   //   const log = history.state;
//   //   if (log.sampId) {
//   //     this.record = this.recordList.find((l) => l.id === log.sampId);
//   //     // const updatedIndex = this.recordList.findIndex((record) => record.id === log.sampId);
//   //     // this.recordList[updatedIndex] = new Log(log.sampId, log.sampDate, log.sampDept, log.sampLog, log.sampEntry, log.sampValue);
//   //     for (var i in this.recordList) {
//   //       if (this.recordList[i].id === log.sampId) {
//   //         this.recordList[i].date = log.sampDate;
//   //         this.recordList[i].department = log.sampDept;
//   //         this.recordList[i].logType = log.sampLog;
//   //         this.recordList[i].entry = log.sampEntry;
//   //         this.recordList[i].value = log.sampValue;
//   //         break;
//   //       }
//   //     }
//   //   }
//   }

//   onCreateLog() {
//     this.openLogModal();
//   }

//   onEdit(logId: string, slidingEl: IonItemSliding) {
//     slidingEl.close();
//     this.router.navigate(['/', 'logs', 'edit-log', logId]);
//   }

//   openLogModal() {
//     this.modctrl
//       .create({
//         component: AddLogComponent,
//         componentProps: { listLength: this.recordList.length },
//       })
//       .then((modalEl) => {
//         modalEl.present();
//         return modalEl.onDidDismiss();
//       })
//       .then((res) => {
//         if (res.role == 'confirm') {
//           this.ls.addNewLog(
//             res.data.logData.department,
//             res.data.logData.logType,
//             res.data.logData.entry,
//             res.data.logData.value,
//             res.data.logData.date
//           ).subscribe();
//           // this.recordList.push(
//           //   new Log(
//           //     res.data.logData.id,
//           //     res.data.logData.department,
//           //     res.data.logData.logType,
//           //     res.data.logData.entry,
//           //     res.data.logData.value,
//           //     res.data.logData.date,
//           //   )
//           // )
//         }
//       });
//   }
// }
